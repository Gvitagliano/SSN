# Example Input 

Example Input files for simulating the reaction: 
- pseudopotentials
- fdf siesta script
-  .XV file with input positons and velocities

(the .old file is an older version and it can be disregarded)
