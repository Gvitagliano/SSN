# Sample python scripts

Python examples based on MDAnalysis, for a Quick Start Guide see [here](https://userguide.mdanalysis.org/stable/examples/quickstart.html)
 ![result](Figure_1.png)

