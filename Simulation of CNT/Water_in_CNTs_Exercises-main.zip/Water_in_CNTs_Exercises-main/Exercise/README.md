# Simulation of Water in Carbon nanotubes
pdb and psf file containing water in contact with a CNT membrane.

The size of the membrane is 23.00 Angstrom in the x direction and 19.919 Angstrom in y direction
The size of the water box is 52.0 Angstrom

Based on the official NAMD tutorial [Simulation of Water Permeation through Nanotubes](https://www.ks.uiuc.edu/Training/Tutorials/#nanotubes).




